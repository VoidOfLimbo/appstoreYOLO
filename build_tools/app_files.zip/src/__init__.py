# TensorRT Model Converter Application
__version__ = "1.0.0"
